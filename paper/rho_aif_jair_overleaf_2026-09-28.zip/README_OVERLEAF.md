# JAIR manuscript for Overleaf

Upload this ZIP using New Project > Upload Project in Overleaf.
Select `full_paper_jair.tex` as the main document and pdfLaTeX as the compiler.
Use a current TeX Live version. BibLaTeX uses Biber, which Overleaf detects.

This source archive contains the JAIR master, bibliography, official jair.cls,
all 24 referenced PDF figures, and all 9 table inputs. Keep figures/
and tables/ beside the main file. Standard TeX Live supplies acmart,
acmauthoryear, acmdatamodel, biblatex, doclicense, fonts, and other packages.

Local build:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error full_paper_jair.tex
```

Alternatively run pdfLaTeX, Biber, then pdfLaTeX twice. The compiled manuscript
PDF and auxiliary files are intentionally omitted. No hosted Overleaf test
or journal submission is performed by the packaging script.

Regenerate from the repository with `python tools/build_overleaf_package.py`.
Upload documentation:
https://docs.overleaf.com/managing-projects-and-files/uploading-a-project
