# JAIR manuscript for Overleaf

Upload this ZIP using New Project > Upload Project in Overleaf.

Set the main document to `full_paper_jair.tex` and the compiler to pdfLaTeX.
Select a current TeX Live version. The bibliography uses BibLaTeX with Biber,
which Overleaf's build process detects automatically. Then select Recompile.

The project contains the JAIR manuscript, its bibliography, the official
`jair.cls`, all 20 referenced PDF figures, and all nine table inputs.
The source is identical to the repository's JAIR master. `figures/` and
`tables/` must remain alongside the main file. The complete author metadata
for de Vries et al. (2025) contains all 16 authors; the journal bibliography
style controls how many names are displayed.

Standard TeX Live supplies `acmart`, `acmauthoryear`, `acmdatamodel`, `biblatex`,
`doclicense`, fonts, and other standard packages. These installed packages
are not duplicated in this source archive. Local validation uses pdfLaTeX,
Biber, and TeX Live 2026. This package has not been uploaded to or compiled
on Overleaf's hosted service.

For a local build from this directory:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error full_paper_jair.tex
```

Or run pdfLaTeX, Biber, and pdfLaTeX twice, in that order.
The compiled manuscript PDF and auxiliary build files are intentionally
omitted. Recompiling generates the current PDF from these sources.

Overleaf instructions:
https://docs.overleaf.com/managing-projects-and-files/uploading-a-project
